package com.diplinkblaze.spacednote.labels;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.diplinkblaze.spacednote.R;

import java.util.ArrayList;

import data.database.OpenHelper;
import data.model.label.Label;
import data.model.label.LabelCatalog;

public class LabelLookupFragment extends DialogFragment {



    private ModeAllLabels modeAllLabels = new ModeAllLabels();
    private ModeLabelLists modeLabelLists = new ModeLabelLists();

    private Mode mode = modeAllLabels;
    private String searchKeyword;

    public LabelLookupFragment() {
        // Required empty public constructor
    }

    public static LabelLookupFragment newInstance() {
        LabelLookupFragment fragment = new LabelLookupFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_label_lookup, container, false);
        initializeViews(contentView);
        updateViews(contentView);
        return contentView;
    }

    private void initializeViews(View contentView) {
        mode.initializeViews((RecyclerView) contentView.findViewById(R.id.fragment_label_lookup_recycler_view));
        EditText searchEditText = contentView.findViewById(R.id.fragment_label_lookup_search_edit_text);
        searchEditText.addTextChangedListener(new SearchTextWatcher());
    }


    private void updateViews(View contentView) {
        mode.updateViews((RecyclerView) contentView.findViewById(R.id.fragment_label_lookup_recycler_view));
    }

    private abstract class Mode {
        abstract void initializeViews(RecyclerView contentFrame);
        abstract void updateViews(RecyclerView contentFrame);
        abstract void onSearchKeywordChanged(String searchKeyword);

        protected void tryUpdateViews() {
            View contentView = getView();
            if (contentView != null) {
                this.updateViews((RecyclerView) contentView.findViewById(R.id.fragment_label_lookup_recycler_view));
            }
        }

        protected void onLabelSelected(long labelId) {
            onLabelLookupItemSelected(labelId);
        }
    }

    private class ModeAllLabels extends Mode{
        private ArrayList<Label> allLabels;
        private ArrayList<Label> selectableLabels;
        private Adapter adapter;
        @Override
        void initializeViews(RecyclerView contentFrame) {
            allLabels = LabelCatalog.getLabels(OpenHelper.getDatabase(getContext()));
            selectableLabels = new ArrayList<>(allLabels);
            adapter = new Adapter(selectableLabels);
            RecyclerView recyclerView = contentFrame.findViewById(R.id.fragment_label_lookup_recycler_view);
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        }

        @Override
        void updateViews(RecyclerView contentFrame) {

        }

        @Override
        void onSearchKeywordChanged(String searchKeyword) {
            if (searchKeyword == null || searchKeyword.length() == 0) {
                selectableLabels = new ArrayList<>(allLabels);
            } else {
                selectableLabels = new ArrayList<>(allLabels.size());
                for (Label label : allLabels) {
                    if (label.getTitle() != null && label.getTitle().toLowerCase()
                            .contains(searchKeyword.toLowerCase())) {
                        selectableLabels.add(label);
                    }
                }
            }
            adapter.updateList(selectableLabels);
        }

        private class Adapter extends RecyclerView.Adapter<ViewHolder> {
            ArrayList<Label> labels;

            public Adapter(ArrayList<Label> labels) {
                this.labels = labels;
            }

            public void updateList(ArrayList<Label> labels) {
                this.labels = labels;
                notifyDataSetChanged();
            }

            @Override
            public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(getContext())
                        .inflate(R.layout.partial_label_lookup_item, parent, false);
                ViewHolder holder = new ViewHolder(itemView);
                return holder;
            }

            @Override
            public void onBindViewHolder(ViewHolder holder, int position) {
                Label label = labels.get(position);
                holder.itemView.setTag(label);
                holder.title.setText(label.getTitle());
            }

            @Override
            public int getItemCount() {
                return labels.size();
            }
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            ImageView icon;
            TextView title;
            TextView details;

            public ViewHolder(View itemView) {
                super(itemView);
                icon = itemView.findViewById(R.id.partial_label_lookup_item_icon);
                title = itemView.findViewById(R.id.partial_label_lookup_item_title);
                details = itemView.findViewById(R.id.partial_label_lookup_item_details);

                details.setVisibility(View.GONE);
                icon.setAlpha(0.5f);
                itemView.setOnClickListener(new OnLabelViewClicked());
            }
        }

        private class OnLabelViewClicked implements View.OnClickListener {
            @Override
            public void onClick(View v) {
                Label label = (Label) v.getTag();
                onLabelSelected(label.getId());
            }
        }
    }

    private class ModeLabelLists extends Mode{
        @Override
        void initializeViews(RecyclerView contentFrame) {

        }

        @Override
        void updateViews(RecyclerView contentFrame) {

        }

        @Override
        void onSearchKeywordChanged(String searchKeyword) {

        }
    }

    private class SearchTextWatcher implements TextWatcher {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            searchKeyword = s.toString();
            mode.onSearchKeywordChanged(searchKeyword);
        }
    }

    //================================== Parent Communication ======================================
    private void onLabelLookupItemSelected(long labelId) {
        getListener().onLabelLookupItemSelected(labelId);
    }

    private OnFragmentInteractionListener getListener() {
        if (getParentFragment() instanceof OnFragmentInteractionListener) {
            return (OnFragmentInteractionListener) getParentFragment();
        } else if (getActivity() instanceof OnFragmentInteractionListener) {
            return (OnFragmentInteractionListener) getActivity();
        } else
            throw new RuntimeException("Parent fragment or activity should implement " +
                    "OnFragmentInteractionListener");
    }

    public interface OnFragmentInteractionListener {
        void onLabelLookupItemSelected(long labelId);
    }
}
