package com.diplinkblaze.spacednote.universal.contract;

/**
 * Created by Ahmad on 10/27/17.
 * All rights reserved.
 */

public interface AveContentChangeListener {
    void aveStateChanged(boolean readOnly);
}
