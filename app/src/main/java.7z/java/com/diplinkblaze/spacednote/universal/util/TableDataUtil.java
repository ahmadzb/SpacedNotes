package com.diplinkblaze.spacednote.universal.util;

/**
 * Created by Ahmad on 11/25/17.
 * All rights reserved.
 */

public class TableDataUtil {

}
