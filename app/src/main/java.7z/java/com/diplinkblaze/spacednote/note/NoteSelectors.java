package com.diplinkblaze.spacednote.note;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import data.model.note.Note;
import data.model.note.NoteCatalog;

/**
 * Created by Ahmad on 01/21/18.
 * All rights reserved.
 */

public class NoteSelectors {

    public static class NotesNotDeletedSelector extends NoteSelector {

        @Override
        protected ArrayList<Note> getNotes(Context context, SQLiteDatabase readableDb) {
            return NoteCatalog.getNotesNotDeleted(readableDb);
        }
    }

    public static class NotesDeletedSelector extends NoteSelector {

        @Override
        protected ArrayList<Note> getNotes(Context context, SQLiteDatabase readableDb) {
            return NoteCatalog.getNotesDeleted(readableDb);
        }
    }
}
