package com.diplinkblaze.spacednote.contract;

/**
 * Created by Ahmad on 10/29/17.
 * All rights reserved.
 */

public interface BackSupportListener {
    boolean onBackPressed();
}
