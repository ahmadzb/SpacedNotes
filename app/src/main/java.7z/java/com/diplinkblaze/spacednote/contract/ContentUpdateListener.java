package com.diplinkblaze.spacednote.contract;

/**
 * Created by Ahmad on 10/30/17.
 * All rights reserved.
 */

public interface ContentUpdateListener {
    void updateContent();
}
