package com.diplinkblaze.spacednote.contract;

import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.diplinkblaze.spacednote.theme.Theme;

import util.Colors;

/**
 * Created by Ahmad on 02/02/18.
 * All rights reserved.
 */

public class BaseActivity extends AppCompatActivity{
    private Colors.ColorCache colorCache;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Theme.applyTheme(this);
    }

    protected int getPrimaryColor() {
        if (colorCache == null) {
            colorCache = new Colors.ColorCache(this);
        }
        return colorCache.primaryColor;
    }

    protected int getAccentColor() {
        if (colorCache == null) {
            colorCache = new Colors.ColorCache(this);
        }
        return colorCache.accentColor;
    }
}
