package data.sync;

import data.drive.DriveOperator;
import data.model.existence.Existence;

/**
 * Created by Ahmad on 02/16/18.
 * All rights reserved.
 */

public class SyncOperators {
    static SyncOperator currentOperator;

    public static SyncOperator getCurrentOperator() {
        if (currentOperator == null) {
            currentOperator = new DriveOperator();
        }
        return currentOperator;
    }

    public static int getCurrentOperatorExistenceFlag() {
        return getOperatorExistenceFlag(getCurrentOperator());
    }

    public static int getOperatorExistenceFlag(SyncOperator operator) {
        if (operator instanceof DriveOperator)
            return Existence.EXISTENCE_FLAG_DRIVE;
        else
            throw new RuntimeException("Operator is not recognized");
    }
}
