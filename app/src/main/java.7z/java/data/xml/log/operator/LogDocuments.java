package data.xml.log.operator;

import android.content.Context;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.annotation.Nullable;

import data.storage.Log;
import data.xml.util.DocumentInitializer;

/**
 * Created by Ahmad on 02/02/18.
 * All rights reserved.
 */

public class LogDocuments {
    public static final int logFileLengthThreshold = 3 * 1024 * 1044;

    //========================================= Document ===========================================
    static Document getDocument(int port, int index, @Nullable DocumentInitializer initializer) throws JDOMException, IOException {
        File documentFile = Log.getLogFile(port, index);
        Document document;
        if (documentFile.exists()) {
            SAXBuilder builder = new SAXBuilder();
            document = builder.build(documentFile);
        } else {
            if (initializer == null) {
                document = null;
            } else {
                document = initializer.initializeDocument();
            }
        }

        return document;
    }



    static void writeDocument(final Document document, int port, int index) {
        try {
            XMLOutputter xmlOutput = new XMLOutputter();
            // display xml
            xmlOutput.setFormat(Format.getPrettyFormat());
            File file = Log.getLogFile(port, index);
            FileOutputStream outputStream = new FileOutputStream(file);
            xmlOutput.output(document, outputStream);
            outputStream.close();
//            LogMetadataOperations.Metadata metadata = LogMetadataOperations.getMetadata();
//            if (metadata.getCurrentLogIndex() == index && file.length() > logFileLengthThreshold) {
//                selfCurrentDocument = null;
//                metadata.setCurrentLogIndex(index + 1);
//                LogMetadataOperations.setMetadataAsync(metadata);
//            } else if (metadata.getCurrentLogIndex() == index) {
//                selfCurrentDocument = document;
//            }TODO
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static boolean doesExceedSizeLimit(final  int port, int index) {
        if (index < LogContract.StartLogIndex) {
            return true;
        }
        File documentFile = Log.getLogFile(port, index);
        return documentFile.length() > logFileLengthThreshold;
    }
}
