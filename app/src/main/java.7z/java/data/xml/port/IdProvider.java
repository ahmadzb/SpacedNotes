package data.xml.port;

import android.content.Context;

import data.model.profiles.ProfileCatalog;
import data.xml.progress.ProgressOperations;

/**
 * Created by Ahmad on 02/18/18.
 * All rights reserved.
 */

public class IdProvider {
    public static long nextProfileId(Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        long localId = port.getLastLocalProfileId() + 1;
        port.setLastLocalProfileId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextCaptureId(Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        long localId = port.getLastLocalCaptureId() + 1;
        port.setLastLocalCaptureId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextNoteId(Context context) {
        return nextNoteId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextNoteId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastNoteId() + 1;
        lastLocalIds.setLastNoteId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextNoteDataId(Context context) {
        return nextNoteDataId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextNoteDataId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastNoteDataId() + 1;
        lastLocalIds.setLastNoteDataId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextTypeId(Context context) {
        return nextTypeId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextTypeId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastTypeId() + 1;
        lastLocalIds.setLastTypeId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextTypeElementId(Context context) {
        return nextTypeElementId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextTypeElementId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastTypeElementId() + 1;
        lastLocalIds.setLastTypeElementId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextPictureId(Context context) {
        return nextPictureId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextPictureId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastPictureId() + 1;
        lastLocalIds.setLastPictureId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextLabelId(Context context) {
        return nextLabelId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextLabelId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastLabelId() + 1;
        lastLocalIds.setLastLabelId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextLabelListId(Context context) {
        return nextLabelListId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextLabelListId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastLabelListId() + 1;
        lastLocalIds.setLastLabelListId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextScheduleId(Context context) {
        return nextScheduleId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextScheduleId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastScheduleId() + 1;
        lastLocalIds.setLastScheduleId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextOccurrenceId(Context context) {
        return nextOccurrenceId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextOccurrenceId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastOccurrenceId() + 1;
        lastLocalIds.setLastOccurrenceId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long nextRevisionPastId(Context context) {
        return nextRevisionPastId(ProfileCatalog.getCurrentProfile(context).getId(), context);
    }

    public static long nextRevisionPastId(long profileId, Context context) {
        Port port = PortOperations.getCurrentPort(context);
        if (port == null)
            throw new RuntimeException("Current port is null, cannot get new id");
        Port.LastLocalIds lastLocalIds = port.getLastLocalIds(profileId);
        long localId = lastLocalIds.getLastRevisionPastId() + 1;
        lastLocalIds.setLastRevisionPastId(localId);
        PortOperations.connectionFor(port.getPort()).writePortAsync(port);
        return PortOperations.getGlobalId(localId, port);
    }

    public static long progressedCumulativeOperationCount(Context context) {
        long cumulativeOperationCount = 0;
        ProgressOperations.Progress progress = ProgressOperations.getProgress(context);
        for (int i = 0; i < PortOperations.getPortsCount(); i++) {
            cumulativeOperationCount += progress.getLastPerformedOperationId(i) + 1;
        }
        return cumulativeOperationCount;
    }
}
