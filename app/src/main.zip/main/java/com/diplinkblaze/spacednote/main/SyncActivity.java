package com.diplinkblaze.spacednote.main;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.diplinkblaze.spacednote.R;
import com.diplinkblaze.spacednote.contract.BaseActivity;

import java.util.LinkedList;

import data.drive.Authentication;
import data.drive.DriveOperator;
import data.sync.SignInException;
import data.sync.SyncFailureException;
import data.sync.SyncOperations;
import data.sync.SyncOperators;
import util.Concurrent.TaskProgress;
import util.Concurrent.TaskProgressStatus;

public class SyncActivity extends BaseActivity {
    private static final String KEY_AUTO_CLOSE = "AutoClose";

    private static final int SIGN_IN_REQUEST = 0;

    private static final int SYNC_STATUS_RUNNING = 0;
    private static final int SYNC_STATUS_FINISHED = 1;
    private static final int SYNC_STATUS_CANCELLED = 2;
    private static final int SYNC_STATUS_FAILURE = 3;
    private static final int SYNC_STATUS_SIGN_IN_FAILURE = 4;

    private static final int LogListThreshold = 200;
    LinkedList<String> logList = new LinkedList<>();

    SyncTask syncTask;

    int syncStatus;

    public static Intent getIntent(Context context) {
        Intent intent = new Intent(context, SyncActivity.class);
        intent.putExtra(KEY_AUTO_CLOSE, false);
        return intent;
    }

    public static Intent getAutoCloseIntent(Context context) {
        Intent intent = new Intent(context, SyncActivity.class);
        intent.putExtra(KEY_AUTO_CLOSE, true);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sync);
        initializeViews();
        updateViews();

        android.support.v7.widget.Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        startSync();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SIGN_IN_REQUEST) {
            if (resultCode == RESULT_OK) {
                startSync();
            } else {
                syncStatus = SYNC_STATUS_SIGN_IN_FAILURE;
                invalidateOptionsMenu();
                updateViews();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void initializeViews() {

    }

    private void updateViews() {
        //LogList
        {
            StringBuilder log = new StringBuilder();
            for (String status : logList) {
                log.append(status).append('\n');
            }
            TextView logTextView = findViewById(R.id.activity_sync_log);
            logTextView.setText(log.toString());
        }
        //Status
        {
            TextView syncStatusTextView = findViewById(R.id.activity_sync_status);
            View progressView = findViewById(R.id.activity_sync_progress_bar);
            if (syncStatus == SYNC_STATUS_RUNNING) {
                syncStatusTextView.setText(R.string.syncing);
                syncStatusTextView.setTextColor(getResources().getColor(R.color.colorNamedGray2));
                progressView.setVisibility(View.VISIBLE);
            } else if (syncStatus == SYNC_STATUS_CANCELLED) {
                syncStatusTextView.setText(R.string.sync_cancelled);
                syncStatusTextView.setTextColor(getResources().getColor(R.color.colorNamedGray2));
                progressView.setVisibility(View.INVISIBLE);
            } else if (syncStatus == SYNC_STATUS_FINISHED) {
                syncStatusTextView.setText(R.string.sync_finished);
                syncStatusTextView.setTextColor(getResources().getColor(R.color.colorNamedGreen));
                progressView.setVisibility(View.INVISIBLE);
            } else if (syncStatus == SYNC_STATUS_FAILURE) {
                syncStatusTextView.setText(R.string.sync_failed);
                syncStatusTextView.setTextColor(getResources().getColor(R.color.colorNamedRed));
                progressView.setVisibility(View.INVISIBLE);
            }else if (syncStatus == SYNC_STATUS_SIGN_IN_FAILURE) {
                syncStatusTextView.setText(R.string.sync_sign_in_failed);
                syncStatusTextView.setTextColor(getResources().getColor(R.color.colorNamedRed));
                progressView.setVisibility(View.INVISIBLE);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sync_menu, menu);
        if (syncStatus == SYNC_STATUS_FINISHED || syncStatus == SYNC_STATUS_RUNNING) {
            menu.removeItem(R.id.sync_menu_retry);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        } else if (item.getItemId() == R.id.sync_menu_retry) {
            startSync();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    //============================================ Sync ============================================
    private void explicitSignIn() {
        if (SyncOperators.getCurrentOperator() instanceof DriveOperator) {
            Intent intent = Authentication.getSignInIntent(this);
            startActivityForResult(intent, SIGN_IN_REQUEST);
        }
    }

    private void startSync() {
        syncTask = new SyncTask();
        syncTask.execute(getApplicationContext());
        syncStatus = SYNC_STATUS_RUNNING;
        updateViews();
    }

    private class SyncTask extends AsyncTask<Context, TaskProgressStatus, Integer> implements TaskProgress {
        @Override
        protected Integer doInBackground(Context... contexts) {
            int result;
            try {
                SyncOperations.sync(this, contexts[0]);
                result = SYNC_STATUS_FINISHED;
            } catch (SignInException e) {
                result = SYNC_STATUS_SIGN_IN_FAILURE;
            } catch (SyncFailureException e) {
                result = SYNC_STATUS_FAILURE;
            }
            return result;
        }

        @Override
        protected void onProgressUpdate(TaskProgressStatus... values) {
            while (logList.size() > LogListThreshold) {
                logList.removeLast();
            }
            String status = values[0].getStatus();
            if (status == null) {
                status = getString(values[0].getStatusResId());
            }
            logList.addFirst(status);
            updateViews();
        }

        @Override
        protected void onPostExecute(Integer result) {
            if (result == SYNC_STATUS_SIGN_IN_FAILURE) {
                syncStatus = SYNC_STATUS_RUNNING;
                explicitSignIn();
            } else {
                syncStatus = result;
            }
            if (syncStatus == SYNC_STATUS_FINISHED) {
                setResult(RESULT_OK);
            }
            if (result == SYNC_STATUS_FINISHED && getIntent().getBooleanExtra(KEY_AUTO_CLOSE, false)) {
                finish();
            }
            invalidateOptionsMenu();
            updateViews();
        }

        @Override
        public void setStatus(String status) {
            TaskProgressStatus s = new TaskProgressStatus();
            s.setStatus(status);
            publishProgress(s);
        }

        @Override
        public void setStatus(int statusResId) {
            TaskProgressStatus status = new TaskProgressStatus();
            status.setStatusResId(statusResId);
            publishProgress(status);
        }
    }
}
