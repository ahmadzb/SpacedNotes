package com.diplinkblaze.spacednote.contract;

import android.os.Bundle;

/**
 * Created by Ahmad on 11/30/17.
 * All rights reserved.
 */

public interface DeliverySupportListener {
    void receiveDelivery(Bundle delivery);
}
