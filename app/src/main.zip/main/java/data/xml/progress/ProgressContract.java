package data.xml.progress;

/**
 * Created by Ahmad on 02/10/18.
 * All rights reserved.
 */

public class ProgressContract {
    public static final String itemName = "Progress";

    public static class PortProgress {
        public static final String itemName = "PortProgress";

        public static final String port = "port";
        public static final String lastPerformedOperation = "lastPerformedOperation";
    }
}
