package data.sync;

/**
 * Created by Ahmad on 02/17/18.
 * All rights reserved.
 */

public class SyncFailureException extends Exception{
}
