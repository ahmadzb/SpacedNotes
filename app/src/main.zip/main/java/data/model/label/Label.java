package data.model.label;


import javax.annotation.concurrent.Immutable;

import exceptions.InvalidItemException;

/**
 * Created by Ahmad on 01/01/18.
 * All rights reserved.
 */

@Immutable
public class Label {
    private long id;
    private String title;
    private Long deleted;
    private boolean isRealized;
    private boolean isInitialized;

    private Label() {
    }

    public static Label newInstance() {
        return new Label();
    }

    public long getId() {
        return id;
    }

    public Label setId(long id) {
        this.id = id;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public Label setTitle(String title) {
        this.title = title;
        return this;
    }

    public Long getDeleted() {
        return deleted;
    }

    public Label setDeleted(Long deleted) {
        this.deleted = deleted;
        return this;
    }

    public boolean isRealized() {
        return isRealized;
    }

    public Label setRealized(boolean realized) {
        isRealized = realized;
        return this;
    }

    public boolean isInitialized() {
        return isInitialized;
    }

    public Label setInitialized(boolean initialized) {
        isInitialized = initialized;
        return this;
    }
}
