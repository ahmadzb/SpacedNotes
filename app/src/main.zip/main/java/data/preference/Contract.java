package data.preference;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.prefs.Preferences;

/**
 * Created by Ahmad on 02/01/18.
 * All rights reserved.
 */

public class Contract {
    private static final String contentPreferences = "content";
    private static final String drivePreferences = "drive";

    static SharedPreferences getContentPreferences(Context context) {
        return context.getSharedPreferences(contentPreferences, Context.MODE_PRIVATE);
    }
}
