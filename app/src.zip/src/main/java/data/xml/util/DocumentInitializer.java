package data.xml.util;

import org.jdom2.Document;

/**
 * Created by Ahmad on 02/10/18.
 * All rights reserved.
 */

public interface DocumentInitializer {
    Document initializeDocument();
}
