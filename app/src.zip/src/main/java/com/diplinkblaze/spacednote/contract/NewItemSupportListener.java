package com.diplinkblaze.spacednote.contract;

/**
 * Created by Ahmad on 10/31/17.
 * All rights reserved.
 */

public interface NewItemSupportListener {
    void newItem();
}
