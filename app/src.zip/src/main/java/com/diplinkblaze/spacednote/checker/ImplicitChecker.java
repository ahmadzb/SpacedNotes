package com.diplinkblaze.spacednote.checker;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Ahmad on 12/11/17.
 * All rights reserved.
 */

public class ImplicitChecker {

    public static boolean runCheck(AppCompatActivity activity, boolean investigate) {
        boolean result = false;//LogProvider.performNewOperationsFromLog(activity);//TODO it should be triggered manually
        return result;
    }

    public static class Model {

    }


}
